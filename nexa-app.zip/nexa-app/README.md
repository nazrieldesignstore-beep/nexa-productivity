# NEXA — Personal Activity Tracker

A personal habit, task, event, and inbox tracker, mobile-first, built for
Indonesian high-school students. Plain HTML/CSS/JavaScript, no framework,
no backend, no build step required.

This is a fully standalone web app. It has **no dependency on Claude,
Claude Artifacts, or any Anthropic API/runtime** — it only uses standard
browser features (`localStorage`, DOM APIs) and Google Fonts (loaded over
a public CDN link in `index.html`).

## Features

- **Dashboard** — daily progress, today's habits/tasks/events, overdue tasks
- **Habits** — recurring activities with custom weekday schedules and streaks
- **Tasks** — one-off items with deadline, priority, and filters (today /
  upcoming / overdue / completed)
- **Events** — scheduled activities with date/time/location
- **Inbox + Quick Add** — jot something down fast, convert it to a
  habit/task/event later
- **Dark mode**, JSON data export, and a demo-data reset
- All data is stored locally in the browser via `localStorage` — nothing
  is sent to a server

## Project structure

```
nexa-app/
├── index.html        # Page markup, loads css/js
├── css/
│   └── styles.css    # All styling (CSS variables for theming)
├── js/
│   └── app.js         # App logic, state, rendering, localStorage persistence
├── public/
│   └── favicon.svg
├── package.json
├── vercel.json        # Static-site config for Vercel
├── netlify.toml        # Static-site config for Netlify
└── README.md
```

## Run locally

No build step or dependencies are required — it's static HTML/CSS/JS.
Any of these work:

```bash
# Option 1: Node's npx (no install needed)
npx serve .

# Option 2: Python
python3 -m http.server 3000

# Option 3: just open index.html directly in a browser
```

Then open the printed local URL (e.g. `http://localhost:3000`).

> Opening `index.html` directly via `file://` also works for this app,
> since it has no routing and uses only `localStorage`.

## Deploy

### Vercel

1. Push this folder to a Git repository (GitHub/GitLab/Bitbucket).
2. In Vercel, "Add New Project" → import the repo.
3. Framework preset: **Other** (no build step). Vercel will pick up
   `vercel.json` automatically — no extra configuration needed.
4. Deploy.

Or with the CLI, from inside `nexa-app/`:

```bash
npx vercel --prod
```

### Netlify

1. Push this folder to a Git repository.
2. In Netlify, "Add new site" → "Import an existing project" → pick the repo.
3. Build command: leave as detected (`netlify.toml` already sets
   publish directory to `.`).
4. Deploy.

Or drag-and-drop the `nexa-app` folder directly onto
[app.netlify.com/drop](https://app.netlify.com/drop) for an instant deploy
with no Git required.

### Any other static host (GitHub Pages, Cloudflare Pages, S3, etc.)

This is a plain static site — upload the contents of `nexa-app/` as-is.
The only requirement is that `index.html`, `css/`, `js/`, and `public/`
stay in the same relative structure.

## Data & persistence

All data (habits, tasks, events, inbox items, completion history, theme
preference) is kept in the browser's `localStorage` under the key
`nexa_data`, as a single JSON object. This means:

- Data is **per-browser, per-device** — it does not sync across devices.
- Clearing site data/cookies in the browser will erase it.
- Use **Settings → Ekspor Data (JSON)** in the app to back up your data,
  and re-import by pasting it back into `localStorage.nexa_data` via the
  browser console if you ever need to restore it (a dedicated import UI
  is a natural next addition — see below).

## Extending it

The app intentionally ships the Phase 1 feature set (dashboard, CRUD for
habits/tasks/events, Quick Add/Inbox, filters, dark mode, export). Natural
next steps, matching the original product spec:

- Full calendar (month/week/day views)
- Charts for weekly/monthly analytics
- XP/streak milestones (gamification)
- Browser push notifications for reminders
- A JSON **import** UI in Settings (export already exists)
- Optional backend sync (the data model in `js/app.js` — `habits`,
  `tasks`, `events`, `inbox` — is already shaped to map onto a real
  database later)

## Browser support

Modern evergreen browsers (Chrome, Safari, Firefox, Edge) on Android,
iOS, and desktop. Uses CSS custom properties, `prefers-color-scheme`,
and `env(safe-area-inset-*)` for notch/gesture-bar safe areas on mobile.

const DAYS=['M','S','S','R','K','J','S'];
const DAYNAMES=['Minggu','Senin','Selasa','Rabu','Kamis','Jumat','Sabtu'];
const uid=()=>Date.now().toString(36)+Math.random().toString(36).slice(2,7);
const todayStr=()=>new Date().toISOString().slice(0,10);

function load(){
  try{return JSON.parse(localStorage.getItem('nexa_data'))||seed();}catch(e){return seed();}
}
function seed(){
  return {
    theme:'light', seeded:true,
    habits:[
      {id:uid(),title:'Qur\'an',icon:'📖',time:'04:00',repeat:[0,1,2,3,4,5,6],completions:{},streak:0},
      {id:uid(),title:'Jogging',icon:'🏃',time:'05:00',repeat:[1,3,5],completions:{},streak:0}
    ],
    tasks:[
      {id:uid(),title:'Tugas PPKN',deadline:todayStr(),priority:'high',status:'todo',createdAt:Date.now()}
    ],
    events:[
      {id:uid(),title:'Latihan Futsal',date:todayStr(),start:'16:00',end:'17:30',location:''}
    ],
    inbox:[]
  };
}
let DB=load();
function save(){ localStorage.setItem('nexa_data', JSON.stringify(DB)); }

let VIEW='home', openMenu=null;

function applyTheme(){
  document.documentElement.setAttribute('data-theme', DB.theme==='dark'?'dark':(DB.theme==='light'?'light':'auto'));
}
applyTheme();

function greet(){
  const h=new Date().getHours();
  if(h<10) return 'Selamat pagi 👋';
  if(h<15) return 'Selamat siang 👋';
  if(h<18) return 'Selamat sore 👋';
  return 'Selamat malam 👋';
}

function habitsToday(){
  const dow=new Date().getDay();
  return DB.habits.filter(h=>h.repeat.includes(dow));
}
function tasksToday(){
  const t=todayStr();
  return DB.tasks.filter(x=>x.status!=='completed' && x.deadline===t);
}
function eventsToday(){
  const t=todayStr();
  return DB.events.filter(x=>x.date===t);
}

function render(){
  const app=document.getElementById('app');
  document.querySelectorAll('.navbtn').forEach(b=>b.classList.toggle('active', b.dataset.view===VIEW));
  if(VIEW==='home') app.innerHTML=renderHome();
  else if(VIEW==='tasks') app.innerHTML=renderTasks();
  else if(VIEW==='inbox') app.innerHTML=renderInbox();
  else app.innerHTML=renderSettings();
  bindDynamic();
}

function progressCalc(){
  const h=habitsToday(), t=todayStr();
  const hDone=h.filter(x=>x.completions[t]).length;
  const tItems=tasksToday(); // todo only (already not completed)
  const tDoneCount=0; // today's remaining tasks are by definition not done; count all-day completed separately
  const allTasksToday=DB.tasks.filter(x=>x.deadline===t);
  const tDone=allTasksToday.filter(x=>x.status==='completed').length;
  const total=h.length+allTasksToday.length;
  const done=hDone+tDone;
  const pct= total? Math.round(done/total*100):0;
  return {done,total,pct};
}

function renderHome(){
  const p=progressCalc();
  const h=habitsToday(), t=todayStr();
  const prioRank={high:0,medium:1,low:2};
  const tasks=tasksToday().sort((a,b)=>prioRank[a.priority]-prioRank[b.priority]);
  const overdue=DB.tasks.filter(x=>x.status!=='completed' && x.deadline && x.deadline<t);
  const evs=eventsToday().sort((a,b)=>a.start.localeCompare(b.start));
  return `
    <div class="hello">${greet()}</div>
    <div class="date">${DAYNAMES[new Date().getDay()]}, ${new Date().toLocaleDateString('id-ID',{day:'numeric',month:'long'})}</div>
    <div class="progress-card">
      <div class="label">Progres Hari Ini</div>
      <div class="big">${p.done} / ${p.total} selesai</div>
      <div class="bar"><span style="width:${p.pct}%"></span></div>
    </div>
    ${overdue.length? `<div class="section-title">🔴 Terlambat</div>${overdue.map(x=>taskCard(x,true)).join('')}`:''}
    <div class="section-title">🔒 Habit</div>
    ${h.length? h.map(x=>habitCard(x)).join(''): emptyState('Belum ada habit.','Tambahkan kebiasaan pertamamu.')}
    <div class="section-title">⚡ Tugas</div>
    ${tasks.length? tasks.map(x=>taskCard(x,false)).join(''): emptyState('🎉 Bersih!','Tidak ada tugas untuk hari ini.')}
    <div class="section-title">📅 Event</div>
    ${evs.length? evs.map(x=>eventCard(x)).join(''): emptyState('Tidak ada event hari ini.','')}
  `;
}

function emptyState(a,b){
  return `<div class="empty">${b?('<span class="emoji">🗂️</span>'):''}<b>${a}</b><br>${b||''}</div>`;
}

function habitCard(hb){
  const t=todayStr(); const done=!!hb.completions[t];
  return `<div class="card">
    <div class="chk ${done?'done':''}" onclick="toggleHabit('${hb.id}')">${done?'✓':''}</div>
    <div class="item-main">
      <div class="item-title ${done?'done':''}">${hb.icon||'🔒'} ${esc(hb.title)}</div>
      <div class="item-meta">${hb.time||''} ${hb.streak?('· 🔥 '+hb.streak+' hari'):''}</div>
    </div>
    ${menuBtn(hb.id,'habit')}
  </div>`;
}
function taskCard(tk,overdue){
  const done=tk.status==='completed';
  const pr=tk.priority||'low';
  return `<div class="card">
    <div class="chk ${done?'done':''}" onclick="toggleTask('${tk.id}')">${done?'✓':''}</div>
    <div class="item-main">
      <div class="item-title ${done?'done':''}">${esc(tk.title)}</div>
      <div class="item-meta">${overdue?'TERLAMBAT · ':''}${tk.deadline? fmtDate(tk.deadline):''}</div>
    </div>
    <span class="badge ${overdue?'overdue':pr}">${overdue?'Terlambat':({high:'Tinggi',medium:'Sedang',low:'Rendah'}[pr])}</span>
    ${menuBtn(tk.id,'task')}
  </div>`;
}
function eventCard(ev){
  return `<div class="card">
    <div class="item-main">
      <div class="item-title">📅 ${esc(ev.title)}</div>
      <div class="item-meta">${ev.start||''}${ev.end?'–'+ev.end:''} ${ev.location?('· '+esc(ev.location)):''}</div>
    </div>
    ${menuBtn(ev.id,'event')}
  </div>`;
}
function fmtDate(d){
  const today=todayStr();
  if(d===today) return 'Hari ini';
  const tmr=new Date(Date.now()+86400000).toISOString().slice(0,10);
  if(d===tmr) return 'Besok';
  return new Date(d).toLocaleDateString('id-ID',{day:'numeric',month:'short'});
}
function menuBtn(id,type){
  const mid=type+'_'+id;
  return `<div class="relwrap">
    <button class="more" onclick="toggleMenu('${mid}')">⋮</button>
    <div class="menu" id="menu_${mid}">
      <button onclick="deleteItem('${type}','${id}')">🗑️ Hapus</button>
    </div>
  </div>`;
}
function toggleMenu(mid){
  const el=document.getElementById('menu_'+mid);
  document.querySelectorAll('.menu').forEach(m=>{if(m!==el)m.classList.remove('open');});
  el.classList.toggle('open');
}
document.addEventListener('click',e=>{
  if(!e.target.closest('.relwrap')) document.querySelectorAll('.menu').forEach(m=>m.classList.remove('open'));
});

function esc(s){return (s||'').replace(/[&<>]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]));}

window.toggleHabit=function(id){
  const h=DB.habits.find(x=>x.id===id); const t=todayStr();
  if(h.completions[t]) delete h.completions[t]; else h.completions[t]=true;
  h.streak=calcStreak(h);
  save(); render();
};
function calcStreak(h){
  let s=0, d=new Date();
  while(true){
    const ds=d.toISOString().slice(0,10);
    const dow=d.getDay();
    if(!h.repeat.includes(dow)){ d.setDate(d.getDate()-1); continue; }
    if(h.completions[ds]){ s++; d.setDate(d.getDate()-1); } else break;
  }
  return s;
}
window.toggleTask=function(id){
  const t=DB.tasks.find(x=>x.id===id);
  t.status = t.status==='completed' ? 'todo' : 'completed';
  save(); render();
};
window.deleteItem=function(type,id){
  if(type==='habit') DB.habits=DB.habits.filter(x=>x.id!==id);
  if(type==='task') DB.tasks=DB.tasks.filter(x=>x.id!==id);
  if(type==='event') DB.events=DB.events.filter(x=>x.id!==id);
  if(type==='inbox') DB.inbox=DB.inbox.filter(x=>x.id!==id);
  save(); render();
};

function renderTasks(){
  const filt=window._taskFilter||'all';
  let list=[...DB.tasks];
  const t=todayStr();
  if(filt==='today') list=list.filter(x=>x.deadline===t && x.status!=='completed');
  else if(filt==='upcoming') list=list.filter(x=>x.deadline>t && x.status!=='completed');
  else if(filt==='overdue') list=list.filter(x=>x.deadline && x.deadline<t && x.status!=='completed');
  else if(filt==='done') list=list.filter(x=>x.status==='completed');
  list.sort((a,b)=>(a.deadline||'').localeCompare(b.deadline||''));
  return `<div class="topbar">Tugas</div>
  <div class="tabs">
    ${['all','today','upcoming','overdue','done'].map(f=>`<div class="tab ${filt===f?'active':''}" onclick="setTaskFilter('${f}')">${{all:'Semua',today:'Hari Ini',upcoming:'Mendatang',overdue:'Terlambat',done:'Selesai'}[f]}</div>`).join('')}
  </div>
  ${list.length? list.map(x=>taskCard(x, x.status!=='completed' && x.deadline && x.deadline<t)).join('') : emptyState('Tidak ada tugas.','')}
  `;
}
window.setTaskFilter=function(f){window._taskFilter=f; render();};

function renderInbox(){
  return `<div class="topbar">Inbox</div>
  <div class="qa-row">
    <input type="text" id="qaInput" placeholder="+ Tambahkan aktivitas..." onkeydown="if(event.key==='Enter')quickAddSubmit()">
    <button onclick="quickAddSubmit()">Tambah</button>
  </div>
  <h2 class="pt"></h2>
  ${DB.inbox.length? DB.inbox.map(it=>`
    <div class="card">
      <div class="item-main"><div class="item-title">${esc(it.text)}</div></div>
    </div>
    <div style="display:flex; gap:7px; margin:-5px 0 12px; flex-wrap:wrap;">
      <button class="tab" onclick="convertInbox('${it.id}','habit')">→ Habit</button>
      <button class="tab" onclick="convertInbox('${it.id}','task')">→ Tugas</button>
      <button class="tab" onclick="convertInbox('${it.id}','event')">→ Event</button>
      <button class="tab" onclick="deleteItem('inbox','${it.id}')">🗑️ Hapus</button>
    </div>
  `).join('') : emptyState('📥 Inbox kosong.','Semua sudah tertata.')}
  `;
}
window.quickAddSubmit=function(){
  const inp=document.getElementById('qaInput');
  const v=inp.value.trim();
  if(!v) return;
  DB.inbox.unshift({id:uid(), text:v, createdAt:Date.now()});
  save(); render();
  setTimeout(()=>{const i=document.getElementById('qaInput'); if(i) i.focus();},50);
};
window.convertInbox=function(id,type){
  const item=DB.inbox.find(x=>x.id===id);
  if(!item) return;
  openSheetForm(type, item.text);
  window._convertingInboxId=id;
};

function renderSettings(){
  return `<div class="topbar">Pengaturan</div>
  <div class="settings-row"><span>🌙 Mode Gelap</span>
    <button class="toggle ${DB.theme==='dark'?'on':''}" onclick="toggleDark()"><span class="knob"></span></button>
  </div>
  <div class="settings-row"><span>📤 Ekspor Data (JSON)</span>
    <button class="tab" onclick="exportData()">Ekspor</button>
  </div>
  <div class="settings-row"><span>🗑️ Hapus Semua Data Demo</span>
    <button class="tab" onclick="resetData()">Reset</button>
  </div>
  <div style="color:var(--sub); font-size:12px; margin-top:16px;">Data tersimpan otomatis di perangkat ini (localStorage).</div>
  `;
}
window.toggleDark=function(){
  DB.theme = DB.theme==='dark' ? 'light' : 'dark';
  save(); applyTheme(); render();
};
window.exportData=function(){
  const blob=new Blob([JSON.stringify(DB,null,2)],{type:'application/json'});
  const a=document.createElement('a');
  a.href=URL.createObjectURL(blob); a.download='nexa-data.json'; a.click();
};
window.resetData=function(){
  if(!confirm('Hapus semua data dan mulai ulang?')) return;
  DB=seed(); save(); render();
};

/* Add Activity Sheet */
const sheetBg=document.getElementById('sheetBg');
const sheetBody=document.getElementById('sheetBody');
document.getElementById('fabBtn').onclick=()=>openSheetMenu();
sheetBg.onclick=(e)=>{ if(e.target===sheetBg) closeSheet(); };
function closeSheet(){ sheetBg.classList.remove('open'); window._convertingInboxId=null; }

function openSheetMenu(){
  sheetBody.innerHTML=`
    <h3>Mau tambah apa?</h3>
    <div class="opt" onclick="openSheetForm('habit')"><div class="oi">🔒</div><div><div class="ot">Habit</div><div class="os">Sesuatu yang ingin diulang</div></div></div>
    <div class="opt" onclick="openSheetForm('task')"><div class="oi">⚡</div><div><div class="ot">Tugas</div><div class="os">Sesuatu yang perlu diselesaikan</div></div></div>
    <div class="opt" onclick="openSheetForm('event')"><div class="oi">📅</div><div><div class="ot">Event</div><div class="os">Dijadwalkan pada waktu tertentu</div></div></div>
    <div class="opt" onclick="openSheetForm('quick')"><div class="oi">⚡</div><div><div class="ot">Quick Add</div><div class="os">Tambah cepat, atur nanti</div></div></div>
  `;
  sheetBg.classList.add('open');
}
window.openSheetForm=function(type, prefill){
  window._formType=type; window._formDays=[1,2,3,4,5]; window._formPrio='medium';
  if(type==='quick'){
    DB.inbox.unshift({id:uid(), text:prefill||'', createdAt:Date.now()});
    save(); closeSheet(); VIEW='inbox'; render();
    setTimeout(()=>{const i=document.getElementById('qaInput'); if(i) i.focus();},80);
    return;
  }
  let body='';
  if(type==='habit') body=`
    <label>Nama Habit</label><input type="text" id="f_title" value="${esc(prefill||'')}" placeholder="Jogging">
    <label>Waktu</label><input type="time" id="f_time" value="05:00">
    <label>Ulangi pada hari</label>
    <div class="days">${DAYS.map((d,i)=>`<div class="daychip ${window._formDays.includes(i)?'sel':''}" data-d="${i}" onclick="toggleDay(${i})">${d}</div>`).join('')}</div>
    <button class="savebtn" onclick="saveHabit()">Simpan Habit</button>`;
  else if(type==='task') body=`
    <label>Nama Tugas</label><input type="text" id="f_title" value="${esc(prefill||'')}" placeholder="Tugas Sosiologi">
    <label>Deadline</label><input type="date" id="f_deadline" value="${todayStr()}">
    <label>Prioritas</label>
    <div class="prio">
      <button class="high sel" data-p="high" onclick="setPrio('high')">🔴 Tinggi</button>
      <button class="medium" data-p="medium" onclick="setPrio('medium')">🟡 Sedang</button>
      <button class="low" data-p="low" onclick="setPrio('low')">🟢 Rendah</button>
    </div>
    <button class="savebtn" onclick="saveTask()">Simpan Tugas</button>`;
  else if(type==='event') body=`
    <label>Nama Event</label><input type="text" id="f_title" value="${esc(prefill||'')}" placeholder="Rapat Rohis">
    <label>Tanggal</label><input type="date" id="f_date" value="${todayStr()}">
    <label>Mulai</label><input type="time" id="f_start" value="16:00">
    <label>Selesai</label><input type="time" id="f_end" value="17:00">
    <label>Lokasi (opsional)</label><input type="text" id="f_loc" placeholder="Aula sekolah">
    <button class="savebtn" onclick="saveEvent()">Simpan Event</button>`;
  // default prio marker reset
  sheetBody.innerHTML=`<button class="backbtn" onclick="openSheetMenu()">‹ Kembali</button><h3>${type==='habit'?'Habit Baru':type==='task'?'Tugas Baru':'Event Baru'}</h3>${body}`;
  sheetBg.classList.add('open');
};
window.toggleDay=function(i){
  const idx=window._formDays.indexOf(i);
  if(idx>-1) window._formDays.splice(idx,1); else window._formDays.push(i);
  document.querySelector(`.daychip[data-d="${i}"]`).classList.toggle('sel');
};
window.setPrio=function(p){
  window._formPrio=p;
  document.querySelectorAll('.prio button').forEach(b=>b.classList.toggle('sel', b.dataset.p===p));
};
function afterSave(){
  if(window._convertingInboxId){ DB.inbox=DB.inbox.filter(x=>x.id!==window._convertingInboxId); window._convertingInboxId=null; }
  save(); closeSheet(); render();
}
window.saveHabit=function(){
  const title=document.getElementById('f_title').value.trim();
  if(!title) return;
  DB.habits.push({id:uid(), title, icon:'🔒', time:document.getElementById('f_time').value, repeat:[...window._formDays], completions:{}, streak:0});
  afterSave();
};
window.saveTask=function(){
  const title=document.getElementById('f_title').value.trim();
  if(!title) return;
  DB.tasks.push({id:uid(), title, deadline:document.getElementById('f_deadline').value, priority:window._formPrio, status:'todo', createdAt:Date.now()});
  afterSave();
};
window.saveEvent=function(){
  const title=document.getElementById('f_title').value.trim();
  if(!title) return;
  DB.events.push({id:uid(), title, date:document.getElementById('f_date').value, start:document.getElementById('f_start').value, end:document.getElementById('f_end').value, location:document.getElementById('f_loc').value});
  afterSave();
};

function bindDynamic(){}

document.querySelectorAll('.navbtn').forEach(b=>b.onclick=()=>{VIEW=b.dataset.view; render();});

render();
